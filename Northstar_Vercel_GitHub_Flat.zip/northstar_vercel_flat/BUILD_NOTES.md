# Northstar Launch — Build Notes

## Package represented
**Launch Website — $2,500**

This implementation is the coded proof-of-concept for the base contractor offer. It is deliberately complete as a lead-generation site without silently including Growth/Operations work.

## Client-facing functionality included
- Responsive multi-page site
- Problem-first homepage navigation
- Heating / Cooling / Indoor Air / Maintenance / Replacement pages
- About / Reviews / Service Areas / Request Service
- Mobile sticky Call / Book / Emergency actions
- Click-to-call
- Service-area ZIP demo
- Short request-service form
- Financing and Comfort Club marketing sections
- Basic schema markup
- Semantic headings and labeled forms
- Keyboard focus states
- Reduced-motion support
- Local assets; no external front-end dependencies

## Production replacements before a real launch
A real client supplies/verifies:
- Legal business name and address
- Real phone and email
- License / insurance claims and numbers
- Actual service area
- Hours and after-hours policy
- Team photography and bios
- Reviews / review profile
- Membership benefits and pricing
- Financing provider, terms and disclosures
- Warranty / workmanship policy
- Privacy / accessibility / terms language
- Approved safety language

## Upgrade hooks intentionally reserved
### Growth
- Jobber / Housecall Pro / similar booking embed
- Financing widget
- Dynamic reviews
- Call tracking
- More service pages
- City/service-area landing pages
- Advanced intake
- Missed-call text workflow

### Operations
- CRM sync
- Lead scoring / assignment
- ZIP/territory routing
- After-hours on-call routing
- Emergency escalation
- SMS/email automations
- Storm mode
- Unsold-estimate follow-up
- Analytics dashboard

## Cost-control rule
Third-party SaaS subscriptions belong to the client. The developer charges for strategy, implementation, testing, documentation and maintenance—not for permanently financing client software.

## Photography / asset pass
The Launch portfolio build now uses a coordinated Northstar WebP photo library instead of the original SVG illustration placeholders. The library includes hero, heating, cooling, indoor-air, maintenance, replacement, technician/team, Comfort Club/lifestyle, reviews, service-area, emergency and seasonal assets. The emergency and seasonal images are intentionally retained as future-ready assets for Growth/Operations campaign states even where Launch does not yet activate those functions.

All generated imagery is portfolio/demo imagery and should be replaced with client-approved photography on a real client project when available. Images are stored locally so the demo does not hot-link external stock assets.
