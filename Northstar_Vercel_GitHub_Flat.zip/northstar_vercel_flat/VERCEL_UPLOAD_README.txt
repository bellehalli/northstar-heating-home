NORTHSTAR GITHUB / VERCEL FLAT BUILD

This package is intentionally flat: all HTML, CSS, JS, and WebP images live at the repository root.

Upload everything in this folder to the root of bellehalli/northstar-heating-home.
If GitHub asks whether to replace existing files, overwrite the HTML/CSS/JS files.
Old SVG placeholder files may be deleted afterward; this build does not reference them.

After the commit, Vercel should automatically redeploy.
Homepage asset references should include hero-home.webp, heating.webp, cooling.webp, indoor-air.webp, maintenance.webp, replacement.webp, technician.webp, and service-areas.webp.
