const toggle=document.querySelector('.nav-toggle');
const links=document.querySelector('.nav-links');
function closeNav(){if(!toggle||!links)return;links.classList.remove('open');toggle.setAttribute('aria-expanded','false');}
if(toggle&&links){
  toggle.addEventListener('click',()=>{const open=links.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
  links.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeNav));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeNav();});
  document.addEventListener('click',e=>{if(links.classList.contains('open')&&!links.contains(e.target)&&!toggle.contains(e.target))closeNav();});
}

document.querySelectorAll('[data-zip-form]').forEach(form=>{
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const input=form.querySelector('input');
    const status=form.querySelector('.status');
    const zip=(input?.value||'').trim();
    const core=['48150','48152','48154','48170','48187','48188','48167','48168','48374','48375','48377','48331','48334','48335','48336','48239','48135','48127','48075','48076'];
    if(!status)return;
    if(!/^\d{5}$/.test(zip)){status.textContent='Enter a 5-digit ZIP code.';status.style.color='#b83d3d';return;}
    if(core.includes(zip)){status.textContent='Yes — this ZIP is inside Northstar’s sample core service area.';status.style.color='#356554';}
    else{status.textContent='This ZIP is outside the sample core list. A real service team would confirm availability.';status.style.color='#647985';}
  });
});

document.querySelectorAll('[data-demo-form]').forEach(form=>{
  form.addEventListener('submit',e=>{
    e.preventDefault();
    if(!form.reportValidity())return;
    const output=form.querySelector('[data-form-status]');
    if(output){output.hidden=false;output.textContent='Thanks — this portfolio demo request was captured on screen only. No information was sent or stored.';output.focus();}
  });
});
